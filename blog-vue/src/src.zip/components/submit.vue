<template>
	<div>
		<!-- <component is="Message" :show="showMessage" :text="textMessage" @buttonSure="MessageSure"/></component> -->
		<component is="Dialog" :show="showDialog" @cencel="DialogCencel"/></component>
		<div class="container">
			<header>
				<span class="headerTitle">投稿</span>
				<span class="submit" @click="submit">提交</span>
			</header>
			<figure>
				<div @click="addCover" class="addCover" ref="addCover">
					<span>+</span>
					<span>添加封面</span>
				</div>
				<img src="" ref="cover"  @click="addCover">
			</figure>
			<component is="ImageUpload" @addCover="addCover" @imagePath="coverPath" v-show="coverupload" /></component>
			<!-- <div class="title" :contenteditable="editable" @input="inputTitle">
				<p class="default">标题</p>
			</div> -->
			<div class="title">
				<input type="text" placeholder="标题">
				<!-- <inputDiv defaults="标题" ref="title"/> -->
			</div>
			<div class="content">
				<!-- <inputDiv defaults="正文" ref="content"/> -->
				<quillEditor :content="content" :options="editorOption" @touchstart="touchstart" />
				<div class="imgcontent">
					<div class="insertimg" ref="imgcontent" contenteditable="false">
						<img src="">
						<div class="desc"></div>
					</div>
					<br ref="br">
				</div>
			</div>
			<!-- <footer>
				<div class="left">
					<span @click="addImage">
						<img src="@/assets/image.png">
					</span>
					<component is="ImageUpload" @addCover="addImage" @imagePath="imagePath" v-show="imageupload" previewheight="auto" desc="true"/></component>
				</div>
				<div class="right">
					<span>设置</span>
				</div>
			</footer> -->
			
		</div>
	</div>
</template>
<script>
	import Vue from 'vue'
	// import inputDiv from '@/components/plug/inputdiv'
	import { quillEditor } from 'vue-quill-editor'
	import 'quill/dist/quill.core.css'
	import 'quill/dist/quill.snow.css'
	import 'quill/dist/quill.bubble.css'
	// import Dialog from '@/components/plug/dialog'
	// import Message from '@/components/plug/message'
	// import ImageUpload from '@/components/imageupload'
	// Vue.component(
	// 	'Message',
	//   	() => import('@/components/plug/message')
	// );
	Vue.component(
		'ImageUpload',
	  	// 这个 `import` 函数会返回一个 `Promise` 对象。
	  	() => import('@/components/imageupload')
	);
	// Vue.component(
	// 	'Dialog',
	//   	// 这个 `import` 函数会返回一个 `Promise` 对象。
	//   	() => import('@/components/plug/dialog')
	// );
	export default{
		name: 'submit',
		data(){
			return{
				title: '',
				// editable: true,
				coverupload: false,
				imageupload: false,
				images: [],
				desc: [],
				cover: '',
				showDialog: false,
				content: '',
				editorOption: {
		          // theme: 'bubble',
		          placeholder: "输入正文内容，支持html",
		          modules: {
		            toolbar: [
		              ['bold', 'italic', 'underline', 'strike', 'blockquote', 'code-block'],
		              [{ 'list': 'ordered'}, { 'list': 'bullet' }],
		              [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
		              [{ 'color': [] }, { 'background': [] }],
		              // [{ 'font': [] }],
		              [{ 'align': [] }],
		              ['link', 'image', 'video'],
		              ['clean']
		            ]
		          }
		        }
				// showMessage: false,
				// textMessage: '提示信息',
			}
		},
		components:{
			// inputDiv,
			quillEditor,
			// ImageUpload,
			// Dialog,
			// Message,
		},
		methods:{
			// // 正在输入标题时
			// inputTitle(event){
			// 	if(event.srcElement.innerText.length >= 50){
			// 		// event.srcElement.contenteditable = "false";
			// 		this.editable = false
			// 	}
			// 	// console.log(event)
			// 	// if(event.srcElement.innerText.length >= 50 || event.inputType == 'insertParagraph'){
			// 	// 	// return false;
			// 	// 	// console.log(444)
			// 	// 	event.returnValue = false;
			// 	// 	// event.srcElement.innerText = event.srcElement.innerText.substr(0,event.srcElement.innerText.length - 2)
			// 	// 	event.srcElement.innerText = event.srcElement.innerText.replace('\n','');
			// 	// 	console.log(document.querySelector('.title').innerText.length)
			// 	// }

			// 	// console.log(document.querySelector('.title').innerText.length)
			// },
			// 正文内容获得焦点
			// clickContent(event){
			// 	const content = event.srcElement? event.srcElement:event.target;
			// 	const el = content.firstChild.firstChild;//正文可编辑元素
			// 	if(el.innerText == ''){
			// 		el.focus();
			// 	}
			// },
			// 显示隐藏封面图片上传
			addCover(){
				this.coverupload = !this.coverupload;
			},
			// 发布
			submit(){
				this.$loading(true,0);
				// console.log(this.$refs.content.$refs.text.innerText)
				// return false;
				const title = this.$refs.title.$refs.text.innerText;//标题文本
				const content = this.$refs.content.$refs.text.innerHTML;//正文HTML
				this.$axios.post('/article/add', {

			    	token: this.$getStorage('token'),
			      	// account: 'test',
			      	// password: '123',
			      	type: 1,
			      	title: title,
			      	content: content,
			      	images: this.images,
			      	desc: this.desc,
			      	cover: this.cover,
				    
				})
				.then((response)=>{
					this.$loading(false);
					// alert(response.data.message);
					// this.textMessage = response.data.message;
					// this.showMessage = true;
					// this.$showMessage(true, response.data.message);
					this.$toast(response.data.message,3000);
					if(response.data.status == 2){
						this.$delStorage('token');
						this.$messageBox(true);
					}
			  	})
			  	.catch(function (error) {
				    // console.log(error);
				    this.$toast('网络异常');
				});
			},
			// 获得上传封面图片地址
			coverPath(data){
				// console.log(event,path);
				this.coverupload = !this.coverupload;
				this.$refs.addCover.style.display = 'none';
				this.$refs.cover.src = data.path;
				this.$refs.cover.style.display = 'block';
				this.cover = data.path;
			},
			// 显示隐藏正文图片上传
			addImage(){
				this.imageupload = !this.imageupload;
			},
			// 获得上传正文图片地址
			imagePath(data){
				// console.log(path);
				this.imageupload = !this.imageupload;
				this.$refs.imgcontent.firstChild.src = data.path;
				this.$refs.imgcontent.lastChild.innerText = data.desc;
				this.$refs.imgcontent.style.pointerEvents = 'none';
				// this.$refs.imgcontent.style.userSelect = 'none';
				this.$refs.content.$refs.text.appendChild(this.$refs.imgcontent.cloneNode(true));
				this.$refs.content.$refs.text.appendChild(this.$refs.br.cloneNode(true));
				this.images.push(data.path);
				this.desc.push(data.desc);
				// this.desc.push(data.path);
				// this.$refs.images.appendChild(this.$refs.inputimg.cloneNode(true));
				// console.log(this.$refs.content.$refs.text)
				console.log(this.desc);
			},
			DialogCencel(){
				this.showDialog = false;
			},
			touchstart(){
				console.log(4)
			}
		},
		mounted(){
			// this.$messageBox(true);
			// console.log(document.querySelectorAll('input[name=img]'));
		},
		created(){
			this.$setTitle('投稿');
			this.$loading(false);
			// console.log(this.$getStorage('usertemp'))
			setTimeout(()=>{
				if(this.$getStorage('token') == null){
					this.$messageBox(true);
				}else{
					this.$messageBox(false);
				}
			})
			// console.log(this.$refs.text)
		}
	}
</script>
<style scoped>
	.container{
		/*height: 100%;*/
		/*width: 100%;*/
		padding: 2rem .5rem;
		background-color: #fff;
	}
	header{
		width: 100%;
		height: 2rem;
		line-height: 2rem;
		position: fixed;
		top: 0;
		z-index: 1;
		background-color: #fff;
		border-bottom: 1px solid rgba(200,200,200,.1);
		/*margin: 0 .5rem;*/
	}
	header .headerTitle{
		/*float: left;*/
		margin-left: .5rem;
	}
	header .submit{
		display: inline-block;
		width: 3rem;
		height: 1.5rem;
		line-height: 1.5rem;
		border: 1px solid #ccc;
		float: right;
		margin: .25rem 1rem;
		text-align: center;
		border-radius: 3px;
		cursor: pointer;
	}
	figure{
		width: 100%;
		max-height: 15rem;
		min-height: 5rem;
		position: relative;
		background-color: #ccc;
		overflow: auto;
	}
	figure .addCover{
		height: 3rem;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		cursor: pointer;
	}
	figure img{
		width: 100%;
		display: none;
	}
	figure .addCover span{
		display: inline-block;
		height: 1.5rem;
		width: 100%;
		text-align: center;
	}
	figure .addCover span:nth-child(1){
		transform: scale(2);
	}
	.title{
		margin: .3rem 0;
    	padding: .2rem 0;
		font-weight: bold;
		border-bottom: 1px solid rgba(200,200,200,.5);
	}
	.title input{
		width: 100%;
		font-size: 1.2rem;
    	font-weight: bold;
	}
	.content{
		min-height: 20rem;
		margin-bottom: 2.1rem;
		background-color: #fff;
	}
	.content img{
		width: 100%;
	}
	.content .imgcontent{
		display: none;
	}
	.content .desc{
		display: none;
	}
	footer{
		width: 100%;
		position: fixed;
		bottom: 0;
		height: 2rem;
		line-height: 2rem;
		z-index: 1;
		background-color: #fff;
		border-top: 1px solid #eee;
	}
	.left img{
		height: 1rem;
	}
	.ql-editor{
		min-height: 5rem;
	}
</style>