<template>
	<div>
		
	</div>
</template>
<script type="text/javascript">
	export default{
		name: 'cotegoryFile',
		data(){
			return{
				
			}
		}
	}
</script>
<style type="text/css" scoped>
	
</style>