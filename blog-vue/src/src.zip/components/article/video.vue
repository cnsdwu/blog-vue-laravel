<template>
	<div>
		
	</div>
</template>
<script type="text/javascript">
	export default{
		name: 'cotegoryVideo',
		data(){
			return{
				
			}
		}
	}
</script>
<style type="text/css" scoped>
	
</style>