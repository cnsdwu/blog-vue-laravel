<template>
	<div>
		music
	</div>
</template>
<script type="text/javascript">
	export default{
		name: 'cotegoryMusic',
		data(){
			return{
				
			}
		}
	}
</script>
<style type="text/css" scoped>
	
</style>