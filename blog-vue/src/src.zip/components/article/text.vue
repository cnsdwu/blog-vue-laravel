<template>
	<div>
		text
	</div>
</template>
<script type="text/javascript">
	export default{
		name: 'cotegoryText',
		data(){
			return{
				
			}
		}
	}
</script>
<style type="text/css" scoped>
	
</style>