<template>
	<div>
		
	</div>
</template>
<script type="text/javascript">
	export default{
		name: 'cotegoryShare',
		data(){
			return{
				
			}
		}
	}
</script>
<style type="text/css" scoped>
	
</style>